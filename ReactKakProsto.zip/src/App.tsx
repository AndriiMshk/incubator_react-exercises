import React, {useState} from 'react';
import {Accordion} from './Accordion';
import {NewComponent} from './NewComponent';
import {Rating} from './Raiting';
import {Rating2, Rating2ValueType} from './Raiting2'
import {OnOff} from './OnOff';
import {Input2} from './Input2';
import { Input3 } from './Input3';
import { Input } from './Input';

function App() {

    // for Accordion
    let [isCollapsed, setIsCollapsed] = useState(false)

    // for OnOff
    let [x, setX] = useState(false)
    const switchOnOff = () => setX(!x)

    // for Rating2 CONTROLLING RATING
    const [rating2Value, setRating2Value] = useState<Rating2ValueType>(0)

    return (
        <div className='root'>
            {/*<div className='accordion'>*/}
            {/*    <Accordion*/}
            {/*        titleValue={'menu'}*/}
            {/*        isCollapsed={isCollapsed}*/}
            {/*        onChange={() => setIsCollapsed(!isCollapsed)}*/}
            {/*    />*/}
            {/*</div>*/}
            {/*<NewComponent/>*/}
            {/*/!*<Rating/>*!/*/}
            <Rating2
                value={rating2Value}
                onClick={(value: Rating2ValueType) => setRating2Value(value)}
            />
            {/*<OnOff*/}
            {/*    x={x}*/}
            {/*    switchOnOff={switchOnOff}*/}
            {/*/>*/}
            <Input/>
            {/*<Input2/>*/}
            {/*<Input3/>*/}
        </div>
    )
}

export default App;
