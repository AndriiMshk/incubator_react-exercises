import React from 'react';
import {AccordionTitle} from './AccordionTitle';
import {AccordionBody} from './AccordionBody';

type AccordionPropsType = {
    titleValue: string
    isCollapsed: boolean
    onChange: () => void
}

export const Accordion: React.FC<AccordionPropsType> = ({
                                                            titleValue,
                                                            isCollapsed,
                                                            onChange
                                                        }) => {
    return (
        <div>
            <AccordionTitle title={titleValue} collapse={onChange}/>
            {isCollapsed && <AccordionBody/>}
        </div>
    )
}