import React, { useState } from 'react';
import { v1 } from 'uuid';
import { InputItem } from './InputItem';
import set = Reflect.set;

type valuesType = {
  id: string
  value: string
  isChecked: boolean
  rating: number
}
const initialValue = [
  { id: v1(), value: 'qwe', isChecked: false, rating: 0 },
  { id: v1(), value: 'qwee', isChecked: true, rating: 1 },
  { id: v1(), value: 'qweee', isChecked: false, rating: 2 },
  { id: v1(), value: 'qweeee', isChecked: true, rating: 3 },
];
export const Input = () => {
  const [value, setValue] = useState<string>('');
  const [values, setValues] = useState<valuesType[]>(initialValue);
  const [filteredValues, setFilteredValues] = useState(values);
  const [error, setError] = useState<string>('');

  // reading value in input
  const inputOnChangeHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValue(e.target.value);
  };

  // add new item
  const addValueHandler = () => {
    if (value.trim() !== '') {
      const newItem = { id: v1(), value, isChecked: false, rating: 0 };
      setValues([newItem, ...values]);
      setValue('');
      setError('');
      setFilteredValues([newItem, ...values]);
    } else {
      setError('ERROR');
      setTimeout(() => {
        setError('');
      }, 1000);
    }
  };
// add new item by press key;
  const addValueKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      addValueHandler();
    }
  };

// change checkbox
  const checkChangeHandler = (select: string, isCheckedSelect: boolean) => {
    setValues(values.map((item) => item.id === select
      ? {...item, isChecked: isCheckedSelect }
      :item));
  };

// remove item
  const removeValueHandler = (id: string) => {
    setValues(values.filter(v => v.id !== id));
  };

// filter items by checkbox
//   const [filterType, setFilterType] = useState<'All' | 'Checked' | 'Unchecked'>('All');
//   const [filterRatingValue, setFilterRatingValue] = useState(0)

  const filterValueHandler = (filter: 'All' | 'Checked' | 'Unchecked') => {
    if (filter === 'All') {
      setFilteredValues(values);
    }
    if (filter === 'Checked') {
      setFilteredValues(values.filter(({ isChecked }) => isChecked));
    }
    if (filter === 'Unchecked') {
      setFilteredValues(values.filter(({ isChecked }) => !isChecked));
    }
  };

  const ratingChange = (id: string, value: number) => {
    let currentValue = values.find(v => v.id === id);
    if (currentValue) {
      currentValue.rating = value;
    }
    setValues([...values]);
  };

  // filter by rating

  const filterByRating = (value: number) => {
    setFilteredValues(values.filter(v => v.rating === value));
  };

  return (
    <div>
      <h4>{error ? `Add text: ${error}` : 'Add text'}</h4>
      <input
        value={value}
        onChange={inputOnChangeHandler}
        onKeyPress={addValueKeyPress} />
      <button onClick={addValueHandler}>+</button>
      <h4>{filteredValues.length === 0 ? 'list is empty' : 'list:'}</h4>
      {filteredValues.map(v => <li key={v.id}>
        <InputItem
          id={v.id}
          value={v.value}
          isChecked={v.isChecked}
          rating={v.rating}
          ratingChange={ratingChange}
          checkChangeHandler={checkChangeHandler}
          removeValueHandler={removeValueHandler} />
      </li>)}
      <div>
      </div>
      <div>
        <button onClick={() => filterValueHandler('All')}>All</button>
        <button onClick={() => filterValueHandler('Checked')}>Checked</button>
        <button onClick={() => filterValueHandler('Unchecked')}>Unchecked</button>
      </div>
      <div>
        <select
          onChange={(event) => filterByRating(+event.target.value)}>
          <option value={1}>1</option>
          <option value={2}>2</option>
          <option value={3}>3</option>
          <option value={4}>4</option>
          <option value={5}>5</option>
        </select>
      </div>
    </div>
  );
};

